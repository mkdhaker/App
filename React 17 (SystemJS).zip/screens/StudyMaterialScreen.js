import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Header from '../components/Header';

const StudyMaterialScreen = () => {
  return (
    <View style={styles.container}>
      <Header title="Study Material" showBackButton />
      <View style={styles.content}>
        <Text>Study Material Screen</Text>
        {/* Add your study material content here */}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default StudyMaterialScreen;