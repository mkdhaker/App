import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Header from '../components/Header';

const MCQTestScreen = () => {
  return (
    <View style={styles.container}>
      <Header title="MCQ Test" showBackButton />
      <View style={styles.content}>
        <Text>MCQ Test Screen</Text>
        {/* Add your MCQ test content here */}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default MCQTestScreen;